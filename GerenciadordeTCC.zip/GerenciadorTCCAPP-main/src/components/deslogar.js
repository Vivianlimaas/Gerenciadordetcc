import React from 'react'

function Deslogar(){
    localStorage.clear()
}
export default Deslogar